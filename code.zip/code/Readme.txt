To run this code correctly it needs the loss.py and preprocessing.py  and layers.py.
the tutorial_GMM is the code using gmm algorithm and the Tutorial_kmean using kmean algorithm.
install the required packages and depencies which mentioned in the report.